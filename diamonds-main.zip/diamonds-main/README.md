# diamonds
Analyzing the diamonds.csv file

Answering to several question from which color is the most available in diamonds to how size of the diamond depend on the clarity and some other question
I used python Pandas package to analyze the csv file and Matplotlib package to visualize them and answer to some questions

I'll let you come with the conclusions based on the information in the file.
Hope you'll enjoy!
